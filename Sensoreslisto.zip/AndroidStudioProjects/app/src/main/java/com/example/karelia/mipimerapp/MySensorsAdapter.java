package com.example.karelia.mipimerapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import static android.support.v4.content.ContextCompat.startActivity;

public class MySensorsAdapter extends ArrayAdapter<Sensor>
{
    private int textViewResourceId;
    private Context context;
    //SensorManager sm =(SensorManager) getContext().bindService()getSystemService(SENSOR_SERVICE);

    private static class ViewHolder
    {
        private TextView itemView;
        private TextView itemView2;
        private Button itemView3;
    }
    public MySensorsAdapter(Context context, int textViewResourceId, List<Sensor> items)
    {
        super(context,textViewResourceId,items);
        this.textViewResourceId = textViewResourceId;
        this.context = context;


        //sm.registerListener(this,items[], SensorManager.SENSOR_DELAY_NORMAL);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT_WATCH)
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        ViewHolder viewHolder = null;
        
        if(convertView==null){
            convertView= LayoutInflater.from(this.getContext()).inflate(textViewResourceId,parent,false);

            viewHolder= new ViewHolder();
            viewHolder.itemView = (TextView) convertView.findViewById(R.id.content);
            viewHolder.itemView2 = (TextView) convertView.findViewById(R.id.textView_Nombre);
            viewHolder.itemView3 = (Button) convertView.findViewById(R.id.button);
            convertView.setTag(viewHolder);
        }
        else
            {
             viewHolder = (ViewHolder) convertView.getTag();
        }


        final Sensor item = getItem(position);
///Acelerometro Magnetometro Giroscopio Luz
        if(item!= null) {
            viewHolder.itemView.setText(Html.fromHtml("<b>Name: </b>"+item.getName()+"<br/>" +
                    "<b>Int Type: </b>"+item.getType()+"<br/>"+
                    "<b>String Type: </b>"+item.getStringType()+"<br/>" +
                    "<b>Vendor: </b>"+item.getVendor()+"<br/>" +
                    "<b>Version:  </b>"+item.getVersion() +"<br/>" +
                    "<b>Resolution: </b>"+item.getResolution()+"<br/>" +
                    "<b>Power: </b>"+item.getPower()+"<br/>"+
                    "<b>Maximum Range: </b>"+item.getMaximumRange()+"<br/>"));
            /*"  Name: " + item.getName() + " \n  Int Type: " + item.getType()
                    + " \n  String Type: " + item.getStringType() + " \n  Vendor: " + item.getVendor()
                    + " \n  Version: " + item.getVersion() + " \n  Resolution: " + item.getResolution()
                    + " \n  Power: " + item.getPower() + " mAh \n  Maximum Range: " + item.getMaximumRange());*/
            viewHolder.itemView2.setText(item.getName());
            //sensor = sm.getDefaultSensor(item.getType());
            //sm.registerListener(this, item, SensorManager.SENSOR_DELAY_FASTEST);
            viewHolder.itemView3.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Code here executes on main thread after user presses button
                    Intent intent = new Intent(context , Main2Activity.class);
                    //intent.putExtra("sensor",item.getId());
                    intent.putExtra("tipo",item.getType());
                    context.startActivity(intent);
                   // sm.registerListener(MySensorsAdapter.this, item, SensorManager.SENSOR_DELAY_FASTEST);

                }

            });
        }
        return convertView;
    }




}

