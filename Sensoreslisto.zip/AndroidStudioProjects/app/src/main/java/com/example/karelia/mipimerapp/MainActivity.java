package com.example.karelia.mipimerapp;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import static java.lang.Math.log;

public class MainActivity extends AppCompatActivity {
    // LinearLayout ln;
    SensorManager sm;
    //Sensor sensor, sensorg;
    //TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);/////
        setContentView(R.layout.activity_main);////

        // ln=(LinearLayout) findViewById(R.id.linear);

        //tv=(TextView) findViewById(R.id.texto);///////
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);//////
        //sensor = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        //sensorg = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        //SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);//////
        ListView list = (ListView) findViewById(R.id.list);
        list.setAdapter(new MySensorsAdapter(this, R.layout.row_item, sensors));
    }


}
     //   sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);

        /////REVISION DE APLICACION DE SENSORES PROX CLASSA
        /*for(Sensor sensor: sensors) {

            tv.append("\n SENSOR: "+sensor.getName()+"\n");

        }*/


    //}

    /*@Override
    public void onSensorChanged(SensorEvent event) {
        String texto=String.valueOf(event.values[0]);
        tv.setText(texto);
        float valor=Float.parseFloat(texto);
        //Toast.makeText(this, "THIS "+texto, Toast.LENGTH_LONG).show();
        if(valor==0)
        {
            //ln.setBackgroundColor(Color.BLACK);
        }
        else
        {
            //ln.setBackgroundColor(Color.GRAY);
        }
        /*synchronized (this) {

            switch(event.sensor.getType()) {

                case Sensor.TYPE_ORIENTATION:

                    for (int i=0 ; i<3 ; i++) {

                        tv.append("Orientación "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;

                case Sensor.TYPE_ACCELEROMETER:

                    for (int i=0 ; i<3 ; i++) {

                        tv.append("Acelerómetro "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;

                case Sensor.TYPE_MAGNETIC_FIELD:

                    for (int i=0 ; i<3 ; i++) {

                        tv.append("Magnetismo "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;
                case Sensor.TYPE_ACCELEROMETER_UNCALIBRATED:

                    for (int i=0 ; i<event.values.length  ; i++) {

                        tv.append("Acelerómetro no calibrado "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;
                case Sensor.TYPE_PROXIMITY:

                    for (int i=0 ; i<event.values.length  ; i++) {

                        tv.append("Proximidad "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;

                default:
                    tv.append("Es un "+event.sensor.getType());
                    for (int i=0 ; i<event.values.length ; i++) {

                        tv.append("Temperatura "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");


                    }

            }

        }*/
        /*Toast.makeText(this, "ESTO ES  "+String.valueOf(event.values[2]) , Toast.LENGTH_LONG).show();
       Toast.makeText(this, "THIS "+String.valueOf(event.values[1])+
                "THIS "+String.valueOf(event.values[2])+
                "THIS "+String.valueOf(event.values[3]) , Toast.LENGTH_LONG).show();

       if(event.values[1] >= 0.5f) { // anticlockwise
        //    Toast.makeText(this, "ROJO ", Toast.LENGTH_LONG).show();
            ln.setBackgroundColor(Color.RED);
        }
        else if(event.values[1] < -0.5f) { // clockwise
            ln.setBackgroundColor(Color.BLUE);
        }

        if(event.values[2] >= 0.5f) { // anticlockwise
            //    Toast.makeText(this, "ROJO ", Toast.LENGTH_LONG).show();
            ln.setBackgroundColor(Color.GREEN);
        }
        else if(event.values[2] < -0.5f) { // clockwise
            ln.setBackgroundColor(Color.YELLOW);
        }
        if(event.values[3] >= 0.5f) { // anticlockwise
            //    Toast.makeText(this, "ROJO ", Toast.LENGTH_LONG).show();
            ln.setBackgroundColor(Color.CYAN);
        }
        else if(event.values[3] < -0.5f) { // clockwise
            ln.setBackgroundColor(Color.DKGRAY);
        }*/
    /*}

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    /*    Toast.makeText(this, "OnCreate", Toast.LENGTH_SHORT).show();
        // La actividad está creada.
    }
    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "OnStart", Toast.LENGTH_SHORT).show();
        // La actividad está a punto de hacerse visible.
    }
    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "OnResume", Toast.LENGTH_SHORT).show();
        // La actividad se ha vuelto visible (ahora se "reanuda").
    }
    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "OnPause", Toast.LENGTH_SHORT).show();
        // Enfocarse en otra actividad  (esta actividad está a punto de ser "detenida").
    }
    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "OnStop", Toast.LENGTH_SHORT).show();
        // La actividad ya no es visible (ahora está "detenida")
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "OnDestroy", Toast.LENGTH_SHORT).show();
        // La actividad esta a punto de ser destruida
    }*/
//}
