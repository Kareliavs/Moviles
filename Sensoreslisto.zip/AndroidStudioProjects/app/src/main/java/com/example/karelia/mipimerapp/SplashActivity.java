package com.example.karelia.mipimerapp;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.pjcom.view.GifView;

public class SplashActivity extends Activity {
    private final int DURACION_SPLASH = 1000;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*ImageView img =(ImageView) findViewById(R.id.ivSplash);
        img.setBackgroundResource(R.drawable.loading);
        AnimationDrawable frameAnimation =(AnimationDrawable) img.getBackground();
        frameAnimation.start();*/
       // frameAnimation.stop();
        //GifView gifView = (GifView) findViewById(R.id.GIFI);
        //gifView.loadGIFResource(R.mipmap.dn);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_splash);
       // com.pjcom.view.GifView gifView = (com.pjcom.view.GifView) findViewById(R.id.GIFI2);
       // gifView.loadGIFResource(R.mipmap.dn);
        ImageView img =(ImageView) findViewById(R.id.ivSplash);
        img.setBackgroundResource(R.drawable.loading);
        AnimationDrawable frameAnimation =(AnimationDrawable) img.getBackground();
        frameAnimation.start();
        com.pjcom.view.GifView gifView = (com.pjcom.view.GifView) findViewById(R.id.GifLoad);
        gifView.loadGIFResource(R.drawable.loader);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            };
        }, DURACION_SPLASH);
    }
}
