package com.example.karelia.mipimerapp;

public class Utils {
}
