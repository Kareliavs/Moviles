package com.example.karelia.mipimerapp;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.PointF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorEventListener2;
import android.hardware.SensorManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.lang.reflect.Array;

import static com.example.karelia.mipimerapp.R.drawable.ball2;

public class Main2Activity extends AppCompatActivity implements SensorEventListener{
    private Button regreso;
    //SensorManager sm =(SensorManager) getSystemService(Context.SENSOR_SERVICE);
    //Sensor sensor;
    private TextView tv;
    private TextView dtv;
    com.pjcom.view.GifView gifView;
    LinearLayout ln;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
        gifView = (com.pjcom.view.GifView) findViewById(R.id.GIFI);
        gifView.loadGIFResource(R.drawable.bar);
        SensorManager sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        regreso =(Button) findViewById(R.id.button2);
        tv =(TextView) findViewById(R.id.textView);
        dtv =(TextView) findViewById(R.id.descripcion);
        ln=(LinearLayout) findViewById(R.id.animacion);

        regreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v1) {
               onBackPressed();
            }
        });
        int SensorTipo =  getIntent().getIntExtra("tipo",0);
        tv.setText(""+SensorTipo);
        dtv.setText("");
        Sensor item = sm.getDefaultSensor(SensorTipo);
        sm.registerListener(this, item, SensorManager.SENSOR_DELAY_GAME);
        //Toast.makeText(Main2Activity.this, "ENTRO OTRA VEZ ",Toast.LENGTH_LONG).show();

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onSensorChanged(SensorEvent event) {
       String texto=String.valueOf(event.values[0]);
        float valor=Float.parseFloat(texto);
        //System.out.print("ENTRO");
        /* for (int i=0 ; i<event.values.length ; i++) {
            Toast.makeText(context, "QUE ES ESTO " + texto +" i: "+String.valueOf(i)+ " EVENTO " + String.valueOf(event.values[i]),Toast.LENGTH_LONG).show();
        }*/
        /*if(valor==0)
        {
            //ln.setBackgroundColor(Color.BLACK);

            Toast.makeText(Main2Activity.this, "CERQUITA ",Toast.LENGTH_LONG).show();
        }
        else
        {
            //ln.setBackgroundColor(Color.GRAY);
            Toast.makeText(Main2Activity.this, "LEJOS",Toast.LENGTH_LONG).show();
        }*/
        synchronized (this) {

            switch(event.sensor.getType()) {

                case Sensor.TYPE_ORIENTATION:
                    tv.setText("Orientacion");
                    dtv.setText("");
                    for (int i=0 ; i<3 ; i++) {

                        dtv.append("Orientación "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;

                case Sensor.TYPE_ACCELEROMETER:
                    tv.setText("Acelerómetro");
                    dtv.setText("");
                    for (int i=0 ; i<3 ; i++) {

                        dtv.append(String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }
                    ln.setBackgroundColor(Color.rgb(44,143,82));
                    gifView.loadGIFResource(R.drawable.ball2);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(100, 100);


                    // Comprobamos si se sale de la pantalla, y en ese caso, modificamos
                    // su valor
                    PointF position = new PointF();
                    // Variables para acceder a los datos del accelerometro
                    final int X = 0;
                    final int Y = 1;
                    final int Z = 2;
                    int HEIGHT=ln.getHeight();
                    int WIDTH=ln.getWidth();
                    // Modificamos la posicion de la bola en el eje X
                    position.x -= event.values[X]*30-HEIGHT/2;
                    if (position.x < 0)
                        position.x = 0;
                    else if (position.x > WIDTH - gifView.getWidth())
                        position.x = WIDTH - gifView.getWidth();
                    // Modificamos la posicion de la bola en el eje Y
                    position.y += HEIGHT/2 + event.values[Y]*50;
                    // Comprobamos si se sale de la pantalla, y en ese caso, modificamos
                    // su valor
                    if (position.y < 0)
                        position.y = 0;
                    else if (position.y > HEIGHT - gifView.getHeight())
                        position.y = HEIGHT - gifView.getHeight();
                    layoutParams.leftMargin = (int) position.x;
                    layoutParams.topMargin = (int) position.y;
                    gifView.setLayoutParams(layoutParams);

            break;

                case Sensor.TYPE_MAGNETIC_FIELD:
                    tv.setText("Magnetismo ");
                    for (int i=0 ; i<3 ; i++) {

                        dtv.append(String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;
                case Sensor.TYPE_ACCELEROMETER_UNCALIBRATED:

                    for (int i=0 ; i<event.values.length  ; i++) {

                        tv.append("Acelerómetro no calibrado "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");

                    }

                    break;
                case Sensor.TYPE_PROXIMITY:
                    tv.setText("Proximidad");
                    dtv.setText("Valores: "+String.valueOf(event.values[0])+"\n");
                    gifView.loadGIFResource(R.drawable.spider);
                    if(event.values[0]==0)
                    {
                        ln.setBackgroundColor(Color.BLACK);
                        gifView.loadGIFResource(R.drawable.gost);
                    }
                    else
                    {
                        int valuo = (int) event.values[0]*10;
                        ln.setBackgroundColor(valuo);
                    }

                    break;
                case Sensor.TYPE_AMBIENT_TEMPERATURE:
                    gifView.loadGIFResource(R.drawable.ambiental);
                    tv.setText("Temperatura Ambiente");
                    dtv.setText(String.valueOf(event.values[0])+" C \n");
                    if(event.values[0]<-150)
                    {
                        ln.setBackgroundColor(Color.rgb(145,145,145));
                    }
                    else if(event.values[0]<0)
                    {
                        ln.setBackgroundColor(Color.rgb(78,155,181));
                    }
                    else if (event.values[0]<50)
                    {
                        ln.setBackgroundColor(Color.rgb(245,186,86));
                    }
                    else
                    {
                        ln.setBackgroundColor(Color.rgb(247,110,72));
                    }
                    break;

                default:
                    tv.setText("Es un "+event.sensor.getType());
                    dtv.setText("");
                    for (int i=0 ; i<event.values.length ; i++) {

                        dtv.append("OTRO "+String.valueOf(i)+": "+String.valueOf(event.values[i])+"\n");


                    }

            }

            GraphView graph = (GraphView) findViewById(R.id.graph);
            graph.removeAllSeries();
            LineGraphSeries<DataPoint> series  = new LineGraphSeries<>();
            for (int i=0 ; i<event.values.length ; i++) {
                series.appendData(new DataPoint(i,event.values[i]),true, 20);
            }
            graph.addSeries(series);



        }
        /*Toast.makeText(this, "ESTO ES  "+String.valueOf(event.values[2]) , Toast.LENGTH_LONG).show();
       Toast.makeText(this, "THIS "+String.valueOf(event.values[1])+
                "THIS "+String.valueOf(event.values[2])+
                "THIS "+String.valueOf(event.values[3]) , Toast.LENGTH_LONG).show();

       if(event.values[1] >= 0.5f) { // anticlockwise
        //    Toast.makeText(this, "ROJO ", Toast.LENGTH_LONG).show();
            ln.setBackgroundColor(Color.RED);
        }
        else if(event.values[1] < -0.5f) { // clockwise
            ln.setBackgroundColor(Color.BLUE);
        }

        if(event.values[2] >= 0.5f) { // anticlockwise
            //    Toast.makeText(this, "ROJO ", Toast.LENGTH_LONG).show();
            ln.setBackgroundColor(Color.GREEN);
        }
        else if(event.values[2] < -0.5f) { // clockwise
            ln.setBackgroundColor(Color.YELLOW);
        }
        if(event.values[3] >= 0.5f) { // anticlockwise
            //    Toast.makeText(this, "ROJO ", Toast.LENGTH_LONG).show();
            ln.setBackgroundColor(Color.CYAN);
        }
        else if(event.values[3] < -0.5f) { // clockwise
            ln.setBackgroundColor(Color.DKGRAY);
        }*/
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
